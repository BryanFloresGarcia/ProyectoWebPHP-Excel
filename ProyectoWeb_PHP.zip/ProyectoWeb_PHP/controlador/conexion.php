<?php
class Conectar
{
     function conectar()
     {
          $serverName = "DESKTOP-7QPRHNG\SQLEXPRESS"; //serverName\instanceName
          $connectionInfo = array("Database" => "probando", "UID" => "usuarioPHP", "PWD" => "1234", "Encrypt" => "no");
          $conn = sqlsrv_connect($serverName, $connectionInfo);

          //if( $conn ) {
          //     echo "Conexión establecida.<br />";
          //}else{
          //     echo "Conexión no se pudo establecer.<br />";
          //     die( print_r( sqlsrv_errors(), true));
          //}
          return $conn;
     }

     function insertarColumnas($array)
     {
          try {
               $conn = Conectar::conectar();
               foreach ($array as $item) {
                    //echo $item . "\n";
                    //$tsql = "ALTER TABLE reporte1 ADD ".$item." VARCHAR(255)";
                    $tsql = "SELECT " . $item . " FROM reporte1";
                    $insertar = sqlsrv_query($conn, $tsql);
                    if ($insertar == FALSE) {
                         $tsql = "ALTER TABLE reporte1 ADD " . $item . " VARCHAR(255)";
                         $insertar = sqlsrv_query($conn, $tsql);
                         if ($insertar == FALSE)
                              echo ("Error! Agregando: " . $item);
                    }

               }

               sqlsrv_close($conn);
          } catch (Exception $e) {
               echo ("Error!");
          }
     }
     function eliminarColumnas($array)
     {
          try {
               $conn = Conectar::conectar();
               foreach ($array as $item) {
                    //echo $item . "\n";
                    //$tsql = "ALTER TABLE reporte1 ADD ".$item." VARCHAR(255)";

                    $tsql = "ALTER TABLE reporte1 DROP COLUMN " . $item;
                    $insertar = sqlsrv_query($conn, $tsql);
                    if ($insertar == FALSE)
                         echo ("Error! Eliminando: " . $item);


               }

               sqlsrv_close($conn);
          } catch (Exception $e) {
               echo ("Error!");
          }
     }
     function escribirCampos($arrayColumna, $arrayDatos)
     {
          try {
               $conn = Conectar::conectar();
               $columnas = "";
               $valores = "";
               $contador = 0;
               foreach ($arrayColumna as $campo) {
                              //echo ("variable campo: " . $campo);
                              if ($contador == 0) {
                                   $contador +=1;
                                   $columnas = "".$campo; 
                              }else{
                                   $columnas = $columnas.", ".$campo;
                              }                    
                         }
               foreach ($arrayDatos as $item) {
                    //
                         foreach ($item as $campo) {
                              //echo ("variable campo: " . $campo);
                              if ($campo == "vacio") {
                                   $campo = "";
                              }
                              if ($contador == 1) {
                                   $contador +=1;
                                   $valores = "".$campo; 
                              }else{
                                   $valores = $valores."', '".$campo;
                              }                    
                         }
                    
                    if ($contador == 2) {
                         $contador = $contador - 1;
                         
                         $tsql = "INSERT INTO Reporte1 (" . $columnas . ") VALUES ('".utf8_decode($valores)."')";
                         $insertar = sqlsrv_query($conn, $tsql);
                         if ($insertar == FALSE)
                              echo ("Error! Agregando: " );// $valores);
                         //break;
                    }
                    
               }
               sqlsrv_close($conn);
               

          } catch (Exception $e) {
               echo ("Error!");
          }
     }

}
?>