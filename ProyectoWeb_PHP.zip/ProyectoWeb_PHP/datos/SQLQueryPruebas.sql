select * from Reporte1;
DELETE FROM Reporte1 WHERE COD>=1;

insert into Reporte1 (FOTO_Comprobante, Ubicacion_establecimiento, Caja_Numero, Nombre, Project_Desc, Fecha_compra, Tipo_Comprobante, RUC_Numero, Establecimiento_Proveedor, Serie_comprobante, Numero_comprobante, Descripcion_compra, Lugar_compra, Rubro_compra, Moneda, Precio_final, FACTURA) values ('ECH001-2024/oRK36dYyQCiBBSZykQTTfF.FOTO_Comprobante.125428.jpg', '','', 'Eber Chilcahue Huamani', 'Lacc/Peru Huatana', '2024-04-17 18:06:00', 'F', '20312057191', 'ESTTIA S.A', 'E001', '21829', 'SERVICIO DE TAXI DE CAYMA - AEROPUERTO, EBER CHILCAHUE', 'AREQUIPA', 'Movilidad', 'soles', '30', 'E001-21829');

ALTER TABLE dbo.doc_exy ALTER COLUMN column_a DECIMAL (5, 2);  