use probando
create TABLE Reporte1(
COD int primary key identity(1,1),
)

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'probando')
BEGIN
    PRINT 'La base de datos "probando" existe.'
END
ELSE
BEGIN
    PRINT 'La base de datos "probando" no existe.'
END

IF OBJECT_ID('reporte1', 'U') IS NOT NULL
BEGIN
    PRINT 'La tabla "reporte1" existe.'
END
ELSE
BEGIN
    PRINT 'La tabla "reporte1" no existe.'
END